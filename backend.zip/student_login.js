async function studentLogin() {

    try {

        const response = await fetch("http://localhost:5000/api/student/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                collegeID: "2024002",
                password: "2024002"
            })
        });

        const data = await response.json();

        alert(JSON.stringify(data));

    } catch (err) {

        alert(err);

    }

}