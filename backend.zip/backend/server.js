console.log(require.resolve("./routes/student"));
const studentRoutes = require("./routes/student");
const express = require("express");
const cors = require("cors");
require("dotenv").config();

const db = require("./config/db");
const app = express();

app.use(cors());
app.use(express.json());
app.use("/api/student", studentRoutes);

app.get("/", (req, res) => {
    res.send("This is my new server 12345");
});

const PORT = 5000;

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});