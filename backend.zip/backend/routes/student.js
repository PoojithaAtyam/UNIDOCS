console.log("student.js loaded");
const express = require("express");
const router = express.Router();

const db = require("../config/db");

router.post("/login", (req, res) => {
    
    console.log("Student login route reached.");

    const { collegeID, password } = req.body;
    console.log(req.body);
    const sql = "SELECT * FROM Students WHERE student_id = ?";

    db.query(sql, [collegeID], (err, results) => {

        if (err) {
            return res.status(500).json({
                message: "Database Error"
            });
        }

        if (results.length === 0) {
            return res.status(401).json({
                message: "Invalid College ID"
            });
        }

        const student = results[0];
        console.log("Student object:", student);
        console.log("Student from DB:", student);
        console.log("Entered password:", password);
        console.log("Database password:", student.password_hash);
        console.log("Type of entered password:", typeof password);
        console.log("Type of database password:", typeof student.password_hash);


        
        if (String(student.password_hash) !== String(password)) {

            return res.status(401).json({
                message: "Incorrect Password"
            });

        }

        res.json({

            success: true,

            firstLogin: student.first_login,

            student: {

                id: student.student_id,

                name: student.name,

                email: student.email,

                department: student.department,

                year: student.year

            }

        });

    });

});

module.exports = router;